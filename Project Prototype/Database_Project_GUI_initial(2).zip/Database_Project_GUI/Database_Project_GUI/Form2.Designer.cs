﻿namespace Database_Project_GUI
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.StEntry = new System.Windows.Forms.Button();
            this.GEntry = new System.Windows.Forms.Button();
            this.FEntry = new System.Windows.Forms.Button();
            this.SEntry = new System.Windows.Forms.Button();
            this.logout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome";
            // 
            // StEntry
            // 
            this.StEntry.Location = new System.Drawing.Point(67, 66);
            this.StEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.StEntry.Name = "StEntry";
            this.StEntry.Size = new System.Drawing.Size(85, 33);
            this.StEntry.TabIndex = 1;
            this.StEntry.Text = "Student Entry";
            this.StEntry.UseVisualStyleBackColor = true;
            this.StEntry.Click += new System.EventHandler(this.Button1_Click);
            // 
            // GEntry
            // 
            this.GEntry.Location = new System.Drawing.Point(67, 151);
            this.GEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GEntry.Name = "GEntry";
            this.GEntry.Size = new System.Drawing.Size(85, 33);
            this.GEntry.TabIndex = 2;
            this.GEntry.Text = "Guest Entry";
            this.GEntry.UseVisualStyleBackColor = true;
            // 
            // FEntry
            // 
            this.FEntry.Location = new System.Drawing.Point(242, 66);
            this.FEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FEntry.Name = "FEntry";
            this.FEntry.Size = new System.Drawing.Size(85, 33);
            this.FEntry.TabIndex = 3;
            this.FEntry.Text = "Faculty Entry";
            this.FEntry.UseVisualStyleBackColor = true;
            this.FEntry.Click += new System.EventHandler(this.FEntry_Click);
            // 
            // SEntry
            // 
            this.SEntry.Location = new System.Drawing.Point(242, 151);
            this.SEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SEntry.Name = "SEntry";
            this.SEntry.Size = new System.Drawing.Size(85, 33);
            this.SEntry.TabIndex = 4;
            this.SEntry.Text = "Staff Entry";
            this.SEntry.UseVisualStyleBackColor = true;
            // 
            // logout
            // 
            this.logout.Location = new System.Drawing.Point(340, 213);
            this.logout.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(57, 27);
            this.logout.TabIndex = 5;
            this.logout.Text = "Log Out";
            this.logout.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(261, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 7;
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 259);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.SEntry);
            this.Controls.Add(this.FEntry);
            this.Controls.Add(this.GEntry);
            this.Controls.Add(this.StEntry);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button StEntry;
        private System.Windows.Forms.Button GEntry;
        private System.Windows.Forms.Button FEntry;
        private System.Windows.Forms.Button SEntry;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label label2;
    }
}