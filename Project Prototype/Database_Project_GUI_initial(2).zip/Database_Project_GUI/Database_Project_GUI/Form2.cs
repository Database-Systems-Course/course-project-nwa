﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Database_Project_GUI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            StartTimer();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        /*private void Label2_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            label2.Text = DateTime.Now.ToString();
        }*/
        System.Windows.Forms.Timer tmr = null;
        private void StartTimer()
        {
            tmr = new System.Windows.Forms.Timer();
            tmr.Interval = 1000;
            tmr.Tick += new EventHandler(tmr_Tick);
            tmr.Enabled = true;
        }

        void tmr_Tick(object sender, EventArgs e)
        {
            //textBox1.Text = DateTime.Now.ToString();
            label2.Text = DateTime.Now.ToString();
        }    
        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void FEntry_Click(object sender, EventArgs e)
        {
            Form4 tmp = new Form4();
            tmp.Show();
            Hide();
        }
    }
}
