﻿namespace Database_Project_GUI
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.StEntry = new System.Windows.Forms.Button();
            this.GEntry = new System.Windows.Forms.Button();
            this.FEntry = new System.Windows.Forms.Button();
            this.SEntry = new System.Windows.Forms.Button();
            this.logout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(125, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // StEntry
            // 
            this.StEntry.BackColor = System.Drawing.Color.Thistle;
            this.StEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StEntry.Location = new System.Drawing.Point(67, 102);
            this.StEntry.Margin = new System.Windows.Forms.Padding(2);
            this.StEntry.Name = "StEntry";
            this.StEntry.Size = new System.Drawing.Size(85, 33);
            this.StEntry.TabIndex = 1;
            this.StEntry.Text = "Student Entry";
            this.StEntry.UseVisualStyleBackColor = false;
            this.StEntry.Click += new System.EventHandler(this.Button1_Click);
            // 
            // GEntry
            // 
            this.GEntry.BackColor = System.Drawing.Color.Thistle;
            this.GEntry.Location = new System.Drawing.Point(67, 167);
            this.GEntry.Margin = new System.Windows.Forms.Padding(2);
            this.GEntry.Name = "GEntry";
            this.GEntry.Size = new System.Drawing.Size(85, 33);
            this.GEntry.TabIndex = 2;
            this.GEntry.Text = "Guest Entry";
            this.GEntry.UseVisualStyleBackColor = false;
            this.GEntry.Click += new System.EventHandler(this.GEntry_Click);
            // 
            // FEntry
            // 
            this.FEntry.BackColor = System.Drawing.Color.Thistle;
            this.FEntry.Location = new System.Drawing.Point(242, 102);
            this.FEntry.Margin = new System.Windows.Forms.Padding(2);
            this.FEntry.Name = "FEntry";
            this.FEntry.Size = new System.Drawing.Size(85, 33);
            this.FEntry.TabIndex = 3;
            this.FEntry.Text = "Faculty Entry";
            this.FEntry.UseVisualStyleBackColor = false;
            this.FEntry.Click += new System.EventHandler(this.FEntry_Click);
            // 
            // SEntry
            // 
            this.SEntry.BackColor = System.Drawing.Color.Thistle;
            this.SEntry.Location = new System.Drawing.Point(242, 167);
            this.SEntry.Margin = new System.Windows.Forms.Padding(2);
            this.SEntry.Name = "SEntry";
            this.SEntry.Size = new System.Drawing.Size(85, 33);
            this.SEntry.TabIndex = 4;
            this.SEntry.Text = "Staff Entry";
            this.SEntry.UseVisualStyleBackColor = false;
            this.SEntry.Click += new System.EventHandler(this.SEntry_Click);
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.Violet;
            this.logout.Location = new System.Drawing.Point(320, 218);
            this.logout.Margin = new System.Windows.Forms.Padding(2);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(67, 30);
            this.logout.TabIndex = 5;
            this.logout.Text = "Log Out";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(261, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 7;
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Database_Project_GUI.Properties.Resources.LOGO1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(98, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orchid;
            this.BackgroundImage = global::Database_Project_GUI.Properties.Resources.bg1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(411, 259);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.SEntry);
            this.Controls.Add(this.FEntry);
            this.Controls.Add(this.GEntry);
            this.Controls.Add(this.StEntry);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button StEntry;
        private System.Windows.Forms.Button GEntry;
        private System.Windows.Forms.Button FEntry;
        private System.Windows.Forms.Button SEntry;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}